# -*- coding: utf-8 -*-
"""
H2 物流 AGL 可行性方案结论 — 模型 + 报告生成器 (v1.0)
=====================================================
基于最新对比文件《美国海外仓VS美国AGL（FBA仓）物流费用对比.xlsx》的公式口径复现：
  - M5 为例：68×48×35cm = 0.11424 m³ = 4.03 cuft（危险品锂电 · Class 9）
  - 500 台/40HQ · 汇率 6.8（对比文件口径；AGL差异看板用 7.25，已在页脚标注）
  - AGL 仓储-90天 = $2.43/cuft/月(危险品·大件·旺季10-12月) × 4.03 × 3月
  - 海外仓 仓储-90天 = ¥0.86/方/天(谷仓口径) × 0.11424 × 90天（文件按 8.84 USD 直算；
    另附 RMB÷6.8 修正口径 $1.30 供敏感性对照——两种口径下结论方向一致）

产出:
  - output/agl_h2_feasibility_conclusion.html  (自包含双击即开)
  - output/agl_h2_feasibility_conclusion.md    (摘要文档)

用法: python scripts/build_agl_h2_conclusion.py
"""
import math

# ── 1. 输入口径（对照对比文件公式）────────────────────────────────────────
FX = 6.8                     # 对比文件汇率 RMB→USD
L, W, H = 68, 48, 35         # cm
CBM = round(L * W * H / 1e6, 6)          # 0.11424 m³ (I7)
CUFT = 4.03                  # 对比文件 I5 = 4.03 (立方英尺)
QTY = 500                    # 台/40HQ

# 海外仓 (FBM 谷仓, 现状)
A = dict(
    head=130000 / QTY / FX,      # ¥130,000/柜 ÷500 ÷6.8 = 38.235
    inbound=4.8 / FX,            # ¥4.8/台 ÷6.8 = 0.706
    tail=36.0,                   # 谷仓尾程（六项 35.03 + 出库 1.50 ≈ 36.5, 文件取 36）
    stor_rate_rmb=0.86,          # 谷仓 ¥/方/天 = 0.66 + 0.2
    stor_90=(0.66 + 0.2) * CBM * 90,   # 文件直算 8.842 (USD 口径)
)
A["stor_90_corr"] = A["stor_90"] / FX   # 若 0.86 为 RMB ÷6.8 → $1.300
A["non_stor"] = A["head"] + A["inbound"] + A["tail"]

# AGL 整柜 → FBA (方案)
B = dict(
    head=70000 / QTY / FX,       # ¥70,000/柜 ÷500 ÷6.8 = 20.588
    tail=39.0,                   # FBA 超大件50-70 非旺37.32/旺40.13 → H2混算38.7≈39
    stor_90=2.43 * CUFT * 3,     # 危险品·大件·旺季 $2.43/cuft/月 ×4.03 ×3月 = 29.379
)
B["non_stor"] = B["head"] + B["tail"]

# ── 2. 核心计算 ──────────────────────────────────────────────────────────
A["total"] = A["non_stor"] + A["stor_90"]
B["total"] = B["non_stor"] + B["stor_90"]
DELTA = B["total"] - A["total"]                       # +5.184  AGL 贵
AGL_ADV_NONSTOR = A["non_stor"] - B["non_stor"]       # 15.353  除仓储外 AGL 省
A_STOR_DAY = A["stor_90"] / 90                        # 0.098246
B_STOR_DAY = B["stor_90"] / 90                        # 0.326430
BE_DAYS = AGL_ADV_NONSTOR / (B_STOR_DAY - A_STOR_DAY) # ≈67.3 天

A_CORR_TOTAL = A["non_stor"] + A["stor_90_corr"]      # 修正口径
DELTA_CORR = B["total"] - A_CORR_TOTAL                # +12.73
BE_DAYS_CORR = AGL_ADV_NONSTOR / (B_STOR_DAY - A_STOR_DAY / FX)  # ≈49.2 天

# 分水岭用: 尾程官方值（供说明）; 包装优化杠杆
TAIL_NONPEAK, TAIL_PEAK = 37.32, 40.13
TAIL_OPT_NONPEAK, TAIL_OPT_PEAK = 23.92, 25.70        # 包装优化→小号大件

# 敏感度网格: D(周转天) × 仓储情景
SCEN = [
    ("危险品·旺季", 2.43, "s1"),
    ("危险品·非旺", 0.78, "s2"),
    ("普货·旺季", 1.40, "s3"),
    ("普货·非旺", 0.56, "s4"),
]
DAYS = [30, 60, 90, 120, 180]


def delta_at(days: int, rate: float) -> float:
    """B−A 单台总差 (US$), 原海外仓仓储口径"""
    b_stor = days / 30 * CUFT * rate
    a_stor = days / 90 * A["stor_90"]
    return AGL_ADV_NONSTOR * -1 + (b_stor - a_stor)  # -AGL_ADV + 仓储差


def be_days_for(rate: float) -> float:
    return AGL_ADV_NONSTOR / (CUFT * rate / 30 - A_STOR_DAY)


# 分水岭曲线（SVG 数据点）
def curve(rate: float, dmin=0.0, dmax=200.0, n=41):
    return [(d, delta_at(d, rate)) for d in [dmin + (dmax - dmin) * i / (n - 1) for i in range(n)]]


def fmt(x: float, nd=2):
    return f"{x:.{nd}f}"


# ── 3. SVG 构建 ──────────────────────────────────────────────────────────
def _sign(val: float) -> str:
    return ("−" if val < 0 else "+") if abs(val) > 0.005 else ""


def svg_waterfall():
    """海外仓 → AGL 六段桥形瀑布图（单台 US$）"""
    W, TOP, ROWS, ROWH = 712, 30, 6, 38
    y = lambda row: TOP + row * ROWH
    scale = 4.6  # px per USD
    x0 = 158.0
    # 几何: lo→hi 为运行总量；label 为「AGL − 海外仓」该行差（负=AGL 省, 与全页一致）
    rows = [("海外仓 合计（现状 FBM 谷仓）", 0, A["total"], "base", A["total"]),
            ("头程海运差 · AGL 半价", A["total"], A["total"] - (A["head"] - B["head"]), "save", B["head"] - A["head"]),
            ("入库操作差 · AGL 免操作费", A["total"] - (A["head"] - B["head"]),
             A["total"] - (A["head"] - B["head"]) - A["inbound"], "save", -A["inbound"]),
            ("尾程配送差 · FBA 贵 $3", A["total"] - (A["head"] - B["head"]) - A["inbound"],
             A["total"] - (A["head"] - B["head"]) - A["inbound"] + (B["tail"] - A["tail"]), "loss", B["tail"] - A["tail"]),
            ("FBA 仓储差 · 危险品旺季×90天", B["total"] - (B["stor_90"] - A["stor_90"]), B["total"], "loss",
             B["stor_90"] - A["stor_90"]),
            ("AGL 整柜 合计（直发 FBA）", 0, B["total"], "loss2", B["total"])]
    ticks = [(i, f"${i}") for i in range(0, 96, 20)]
    out = []
    for x, t in ticks:
        xx = x0 + x * scale
        out.append(f'<line x1="{xx:.1f}" y1="{TOP}" x2="{xx:.1f}" y2="{TOP+ROWS*ROWH}" stroke="var(--grid)" stroke-width="1"/>'
                   f'<text x="{xx:.1f}" y="{TOP+ROWS*ROWH+14}" text-anchor="middle" font-size="10" fill="var(--ink-3)">{t}</text>')
    for i, (name, lo, hi, kind, val) in enumerate(rows):
        ry = y(i)
        if kind == "base":
            fill, tx = "var(--base-fill)", "var(--ink-2)"
        elif kind == "save":
            fill, tx = "var(--save-fill)", "var(--save)"
        else:
            fill, tx = "var(--loss-fill)", "var(--loss)"
        xa, xb = x0 + lo * scale, x0 + hi * scale
        if xb < xa:
            xa, xb = xb, xa
        w = max(xb - xa, 2.0)
        lbl = f"{val:.2f}" if kind in ("base", "loss2") else f"{_sign(val)}{abs(val):.2f}"
        out.append(f'<text x="{x0-12:.1f}" y="{ry+13.5:.1f}" text-anchor="end" font-size="11.5" fill="var(--ink-2)">{name}</text>')
        out.append(f'<rect x="{xa:.1f}" y="{ry:.1f}" width="{w:.1f}" height="20" rx="2" fill="{fill}">'
                   f'<title>{name} {_sign(val)}${abs(val):.2f}</title></rect>')
        out.append(f'<text x="{xb+6:.1f}" y="{ry+13.5:.1f}" text-anchor="start" font-size="11" font-weight="650" fill="{tx}">{lbl}</text>')
        if i < len(rows) - 1:
            nxt_lo = rows[i + 1][2] * scale + x0
            out.append(f'<line x1="{xb:.1f}" y1="{ry+20}" x2="{nxt_lo:.1f}" y2="{ry+ROWH}" stroke="var(--line-strong)" stroke-width="1"/>')
    return (f'<svg viewBox="0 0 {W} {TOP+ROWS*ROWH+26}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="单台成本瀑布图">'
            + "".join(out) + "</svg>")


def svg_breakeven():
    """周转天数 → AGL−海外仓 单台差 (US$) 曲线 + 盈亏平衡线"""
    W, H, ml, mr, mt, mb = 712, 340, 118, 24, 24, 44
    DMAX = 200.0
    YMAX, YMIN = 36.0, -36.0
    def px(d): return ml + (d / DMAX) * (W - ml - mr)
    def py(v): return mt + (YMAX - v) / (YMAX - YMIN) * (H - mt - mb)
    out = []
    # 网格 + 0 轴
    for d in range(0, 201, 50):
        out.append(f'<line x1="{px(d):.1f}" y1="{mt}" x2="{px(d):.1f}" y2="{H-mb}" stroke="var(--grid)" stroke-width="1"/>'
                   f'<text x="{px(d):.1f}" y="{H-mb+16}" text-anchor="middle" font-size="10.5" fill="var(--ink-3)">{d}天</text>')
    for v in range(-30, 31, 10):
        out.append(f'<line x1="{ml}" y1="{py(v):.1f}" x2="{W-mr}" y2="{py(v):.1f}" stroke="var(--grid)" stroke-width="1"/>'
                   f'<text x="{ml-6:.1f}" y="{py(v)+3.5:.1f}" text-anchor="end" font-size="10" fill="var(--ink-3)">{"−" if v<0 else ""}${abs(v)}</text>')
    zy = py(0)
    out.append(f'<line x1="{ml}" y1="{zy:.1f}" x2="{W-mr}" y2="{zy:.1f}" stroke="var(--line-strong)" stroke-width="1.5" stroke-dasharray="5 4"/>'
               f'<text x="{W-mr-4:.1f}" y="{zy-5:.1f}" text-anchor="end" font-size="10.5" font-weight="700" fill="var(--ink-3)">AGL 与海外仓打平</text>')
    # 情景曲线
    style = {"s1": ("var(--loss)", 2.2), "s2": ("var(--save)", 1.6),
             "s3": ("var(--warn-fill)", 1.6), "s4": ("var(--fee-tail)", 1.6)}
    for name, rate, key in SCEN:
        pts = curve(rate, 0, DMAX)
        col, sw = style[key]
        d = "".join(f'{"L" if i else "M"}{px(x):.1f} {py(v):.1f}' for i, (x, v) in enumerate(pts))
        out.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{sw}"/>')
        # 端点标签
        ex, ev = pts[-1]
        out.append(f'<text x="{px(ex)-4:.1f}" y="{py(ev)-5:.1f}" text-anchor="end" font-size="10.5" font-weight="650" fill="{col}">{name}</text>')
    # 盈亏平衡标记
    for name, rate, key in SCEN:
        be = be_days_for(rate)
        if 0 < be < DMAX:
            col = style[key][0]
            out.append(f'<line x1="{px(be):.1f}" y1="{py(0)}" x2="{px(be):.1f}" y2="{py(0)+5:.1f}" stroke="{col}" stroke-width="2"/>')
            out.append(f'<text x="{px(be):.1f}" y="{py(0)+17:.1f}" text-anchor="middle" font-size="9.5" font-weight="700" fill="{col}">{be:.0f}天</text>')
    # 分区
    out.append(f'<text x="{ml}" y="{mt+16}" font-size="11" font-weight="700" fill="var(--save)">← AGL 更省</text>'
               f'<text x="{W-mr}" y="{mt+16}" text-anchor="end" font-size="11" font-weight="700" fill="var(--loss)">海外仓 更省 →</text>')
    out.append(f'<text x="{W-mr}" y="{H-8}" text-anchor="end" font-size="10" fill="var(--ink-3)">横轴：一柜货在仓滞留天数 D（FBA 月度仓储 × 危险品/普货 × 旺季/非旺）· 纵轴：AGL−海外仓 单台差 US$</text>')
    return f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="盈亏平衡曲线">' + "".join(out) + "</svg>"


def sens_table():
    """敏感度矩阵 (D × 情景) → B−A 单台差 US$, 热力色"""
    rows = []
    for d in DAYS:
        cells = []
        for name, rate, key in SCEN:
            v = delta_at(d, rate)
            cls = "pos" if v > 0 else ("neg" if v < -0.1 else "be")
            cells.append(f'<td class="{cls}">{fmt(v)}</td>')
        rows.append(f'<tr><td class="sname">{d} 天</td>{"".join(cells)}</tr>')
    head = "".join(f'<th>{n}</th>' for n, _, _ in SCEN)
    return (f'<div class="tblwrap"><table><thead><tr><th>滞留 D</th>{head}</tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div>')


def scen_cards():
    cards = []
    for name, rate, key in SCEN:
        be = be_days_for(rate)
        d90 = delta_at(90, rate)
        if not (0 < be < 400):
            # 分水岭不存在（AGL 全天候省）：负斜率或分水岭远超 180 天
            cls = "card-ok"
            chip_c, dotc = "chip-ok", "dot-save"
            num, unit = f"{abs(d90):.2f}", "$/台 @90天"
            sub = f"90 天口径 AGL 每台省 ${abs(d90):.2f} · 滞留天数不构成威胁（分水岭不存在）"
        elif d90 <= 0:
            cls = "card-ok"
            chip_c, dotc = "chip-ok", "dot-save"
            num, unit = f"{be:.0f}", "天分水岭"
            sub = f"90 天口径 AGL 每台省 ${abs(d90):.2f} · 滞留超过 {be:.0f} 天才会翻盘"
        else:
            cls = "card-warn" if be > 90 else "card-bad"
            chip_c, dotc = ("chip-warn", "dot-warn") if cls == "card-warn" else ("chip-bad", "dot-loss")
            num, unit = f"{be:.0f}", "天分水岭"
            sub = f"90 天口径 AGL 每台贵 ${d90:.2f} · 滞留少于 {be:.0f} 天可翻转"
        cards.append(
            f'<article class="card {cls}"><div class="card-top">'
            f'<span class="chip {chip_c}"><span class="dot {dotc}"></span>{name}</span></div>'
            f'<div class="hero"><span class="num">{num}</span><span class="unit">{unit}</span></div>'
            f'<p class="sub">{sub}</p></article>')
    return "".join(cards)


# ── 4. HTML 装配 ─────────────────────────────────────────────────────────
def build_html() -> str:
    delt = DELTA
    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>H2 物流 AGL 可行性结论</title>
<style>
  :root{{
    color-scheme:light;
    --page:#f4f5f7; --surface:#ffffff; --surface-2:#f7f8fa;
    --ink:#16181d; --ink-2:#4b4f57; --ink-3:#7a7e87;
    --line:#e3e5ea; --line-strong:#d0d3da; --grid:#e9eaee;
    --accent:#2a78d6;
    --save:#0ca30c; --save-fill:#0ca30c; --save-bg:#e7f6e9;
    --loss:#d03b3b; --loss-fill:#d03b3b; --loss-bg:#fbe9e9;
    --warn:#8a5b00; --warn-fill:#fab219; --warn-bg:#fdf3dc;
    --base-fill:#c3c2b7;
    --fee-head:#2a78d6; --fee-tail:#eb6834; --fee-storage:#1baf7a;
  }}
  @media (prefers-color-scheme:dark){{
    :root:not([data-theme="light"]){{
      color-scheme:dark;
      --page:#0d0d0d; --surface:#1a1a19; --surface-2:#212120;
      --ink:#ffffff; --ink-2:#c3c2b7; --ink-3:#898781;
      --line:#2c2c2a; --line-strong:#3a3a37; --grid:#2c2c2a;
      --accent:#3987e5;
      --save:#0ca30c; --save-fill:#0ca30c; --save-bg:#12321a;
      --loss:#e66767; --loss-fill:#d03b3b; --loss-bg:#3a1a1a;
      --warn:#e6b33c; --warn-fill:#c98500; --warn-bg:#3a2d12;
      --base-fill:#383835;
      --fee-head:#3987e5; --fee-tail:#d95926; --fee-storage:#199e70;
    }}
  }}
  :root[data-theme="dark"]{{
    color-scheme:dark;
    --page:#0d0d0d; --surface:#1a1a19; --surface-2:#212120;
    --ink:#ffffff; --ink-2:#c3c2b7; --ink-3:#898781;
    --line:#2c2c2a; --line-strong:#3a3a37; --grid:#2c2c2a;
    --accent:#3987e5;
    --save:#0ca30c; --save-fill:#0ca30c; --save-bg:#12321a;
    --loss:#e66767; --loss-fill:#d03b3b; --loss-bg:#3a1a1a;
    --warn:#e6b33c; --warn-fill:#c98500; --warn-bg:#3a2d12;
    --base-fill:#383835;
    --fee-head:#3987e5; --fee-tail:#d95926; --fee-storage:#199e70;
  }}
  *{{box-sizing:border-box;margin:0;padding:0;}}
  body{{font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif;
       background:var(--page);color:var(--ink);line-height:1.6;-webkit-font-smoothing:antialiased;}}
  .wrap{{max-width:1120px;margin:0 auto;padding:40px 28px 56px;}}
  header{{margin-bottom:26px;}}
  .eyebrow{{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--ink-3);
           font-weight:600;margin-bottom:8px;}}
  .badge{{display:inline-block;margin-left:10px;font-size:11px;font-weight:700;letter-spacing:.02em;
         color:var(--accent);border:1px solid var(--accent);padding:2px 9px;border-radius:999px;vertical-align:1px;}}
  h1{{font-size:28px;font-weight:750;letter-spacing:-.01em;line-height:1.2;}}
  .thesis{{margin-top:10px;font-size:15px;color:var(--ink-2);max-width:76ch;}}
  .thesis b{{color:var(--accent);font-weight:650;}}
  .thesis .hl-bad{{color:var(--loss);font-weight:700;}}
  .thesis .hl-ok{{color:var(--save);font-weight:700;}}
  .meta{{margin-top:10px;font-size:12px;color:var(--ink-3);}}
  .cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;margin:6px 0 34px;}}
  .card{{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:18px 20px;border-top:3px solid var(--line);}}
  .card-ok{{border-top-color:var(--save);}}
  .card-warn{{border-top-color:var(--warn-fill);}}
  .card-bad{{border-top-color:var(--loss);}}
  .card-top{{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;}}
  .chip{{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:600;padding:3px 10px;border-radius:999px;white-space:nowrap;}}
  .chip-ok{{background:var(--save-bg);color:var(--save);}}
  .chip-warn{{background:var(--warn-bg);color:var(--warn);}}
  .chip-bad{{background:var(--loss-bg);color:var(--loss);}}
  .dot{{width:8px;height:8px;border-radius:50%;flex:none;}}
  .dot-save{{background:var(--save);}}
  .dot-warn{{background:var(--warn-fill);}}
  .dot-loss{{background:var(--loss);}}
  .hero{{display:flex;align-items:baseline;gap:6px;font-variant-numeric:tabular-nums;}}
  .hero .num{{font-size:40px;font-weight:760;letter-spacing:-.02em;line-height:1;}}
  .hero .unit{{font-size:13px;color:var(--ink-3);}}
  .card-ok .num{{color:var(--save);}}
  .card-warn .num{{color:var(--warn);}}
  .card-bad .num{{color:var(--loss);}}
  .sub{{font-size:13px;color:var(--ink-2);margin-top:8px;}}
  h2{{font-size:17px;font-weight:700;margin:0 0 4px;}}
  .lede{{font-size:13px;color:var(--ink-3);margin-bottom:16px;}}
  .wf{{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px 20px 14px;margin:0 0 14px;}}
  .wf figcaption{{display:flex;align-items:baseline;gap:12px;margin-bottom:6px;flex-wrap:wrap;}}
  .wf-name{{font-size:16px;font-weight:750;}}
  .wf-sub{{font-size:12.5px;color:var(--ink-3);}}
  .net{{margin-left:auto;font-size:16px;font-weight:760;font-variant-numeric:tabular-nums;}}
  .net-loss{{color:var(--loss);}}
  .wf svg,.be svg{{width:100%;height:auto;display:block;}}
  .be{{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px 20px 14px;margin:0 0 14px;}}
  table{{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--line);
        border-radius:12px;overflow:hidden;font-size:13px;margin-top:8px;}}
  th{{background:var(--surface-2);padding:10px 12px;text-align:right;font-weight:650;color:var(--ink-2);
      border-bottom:1px solid var(--line);white-space:nowrap;}}
  th:first-child,th:nth-child(2),td.sname{{text-align:left;}}
  td{{padding:11px 12px;text-align:right;border-bottom:1px solid var(--line);
      font-variant-numeric:tabular-nums;white-space:nowrap;}}
  tbody tr:last-child td{{border-bottom:none;}}
  .sname{{font-weight:700;}}
  .pos{{color:var(--loss);font-weight:650;}}
  .neg{{color:var(--save);font-weight:650;}}
  .be{{color:var(--ink);}}
  .foot{{margin-top:20px;font-size:12px;color:var(--ink-3);}}
  .foot b{{color:var(--ink-2);}}
  .tblwrap{{overflow-x:auto;}}
  .risk-cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px;margin:6px 0 14px;}}
  .risk{{background:var(--surface);border:1px solid var(--line);border-left:3px solid var(--warn-fill);
        border-radius:10px;padding:14px 16px;}}
  .risk h3{{font-size:13.5px;font-weight:700;margin-bottom:6px;color:var(--warn);}}
  .risk p{{font-size:12.5px;color:var(--ink-2);}}
  .risk p b{{color:var(--ink);}}
  .levers{{background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:16px 20px;margin:0 0 14px;}}
  .levers ol{{margin:6px 0 0 20px;font-size:13px;color:var(--ink-2);}}
  .levers li{{margin-bottom:8px;}}
  .levers b{{color:var(--ink);}}
  .note{{font-size:12px;color:var(--ink-3);margin-top:10px;}}
</style>
</head>
<body>
<div class="wrap">

<header>
  <div class="eyebrow">H2 物流 · AGL 可行性方案结论<span class="badge">v1.0 定稿</span></div>
  <h1>H2 全盘切 AGL，可行吗？</h1>
  <p class="thesis">按最新对比文件（M5 为例 · 68×48×35cm · 危险品锂电 · 超大件 50–70 · 500 台/40HQ · 汇率 6.8）：
  90 天库存、危险品旺季仓储口径下，AGL 整柜每台<span class="hl-bad">贵 ${fmt(delt)}</span>，<b>全盘切不可行</b>；
  但 AGL 头程红利每台 <span class="hl-ok">$17.65</span> 真实存在（头程半价 + 免入库操作费），
  被 FBA 尾程（+$3）与旺季危险品仓储（+$20.54）吃掉。</p>
  <div class="meta">口径：对比文件《美国海外仓VS美国AGL（FBA仓）物流费用对比.xlsx》公式复现 · 汇率 6.8 · 尾程 FBA=超大件50-70 非旺$37.32/旺$40.13 的 H2 混算≈$39（对比文件取 39）·
  AGL 仓储-$90天=$2.43/cuft/月（危险品·大件·旺季 10–12 月）×4.03cuft×3 · 谷仓仓储-90天=¥0.86/方/天×0.11424×90 ·
  到仓即撞 FBA 仓储旺季 10–12 月 · 生成 {GENERATED}</div>
</header>

<section class="cards">
  <article class="card card-bad">
    <div class="card-top"><span class="chip chip-bad"><span class="dot dot-loss"></span>90天 · 危险品旺季</span></div>
    <div class="hero"><span class="num">${fmt(delt)}</span><span class="unit">/台 · AGL 贵</span></div>
    <p class="sub">全盘切 AGL 整柜：每台多花 ${fmt(delt)}（合 ¥{fmt(delt*FX)}），<b>一票否决式切换不可行</b>。</p>
  </article>
  <article class="card card-warn">
    <div class="card-top"><span class="chip chip-warn"><span class="dot dot-warn"></span>分水岭 = 周转天数 D</span></div>
    <div class="hero"><span class="num">{fmt(BE_DAYS,1)}</span><span class="unit">天</span></div>
    <p class="sub">D &lt; {fmt(BE_DAYS,1)} 天 AGL 赢、D &gt; {fmt(BE_DAYS,1)} 天海外仓赢。快销品 AGL 可行，慢销/备货留海外仓。</p>
  </article>
  <article class="card card-ok">
    <div class="card-top"><span class="chip chip-ok"><span class="dot dot-save"></span>AGL 除仓储外净省</span></div>
    <div class="hero"><span class="num">${fmt(AGL_ADV_NONSTOR)}</span><span class="unit">/台</span></div>
    <p class="sub">头程半价 −$17.65 + 免入库操作费 −$0.71，再被 FBA 尾程 +$3 抵消 = 除仓储外每台省 ${fmt(AGL_ADV_NONSTOR)}。胜负全押在仓储上。</p>
  </article>
</section>

<section>
  <h2>省在哪、亏在哪 —— 一柜货的单台瀑布</h2>
  <p class="lede">从「海外仓 现状」出发，逐步拆到「AGL 整柜 → FBA」：绿＝AGL 省，红＝AGL 多花。最后一段是净差。</p>
  <figure class="wf">
    <figcaption><span class="wf-name">M5 · 单台全链路成本</span><span class="wf-sub">US$/台 · 90 天滞留 · 危险品旺季仓储</span><span class="net net-loss">AGL 贵 ${fmt(delt)}</span></figcaption>
    {svg_waterfall()}
  </figure>
</section>

<section>
  <h2>分水岭 = 周转天数 D —— 四情景盈亏平衡</h2>
  <p class="lede">横轴 = 一柜货在 FBA 的滞留天数 D；纵轴 = AGL − 海外仓 单台差（&lt;0 绿=AGL 省，&gt;0 红=海外仓省）。危险品×旺季是唯一能击穿 AGL 红利的组合。</p>
  <figure class="be">
    <figcaption><span class="wf-name">D → 单台差 曲线</span><span class="wf-sub">危险品/普货 × 旺季/非旺 四情景</span></figcaption>
    {svg_breakeven()}
  </figure>
  {scen_cards()}
</section>

<section>
  <h2>敏感度矩阵 —— 每台差 US$（负＝AGL 省）</h2>
  <p class="lede">行 = 滞留天数 D，列 = 仓储费率情景。底色逻辑：绿＝AGL 省，红＝AGL 贵。原海外仓仓储口径（¥0.86/方/天 直算 $8.84/90天）。</p>
  {sens_table()}
  <p class="foot">若谷仓仓储 ¥0.86/方/天 按 RMB÷6.8 折算（$1.30/90 天），则海外仓合计降为 $76.24，
  危险品·旺季下 AGL 每台贵 <b>${fmt(DELTA_CORR)}</b>、分水岭 D≈{fmt(BE_DAYS_CORR,1)} 天 —— 结论方向不变且更保守。</p>
</section>

<section>
  <h2>为什么 90 天只是开始 —— 风险放大量</h2>
  <p class="lede">H2 走 AGL 的隐性成本不止月度仓储：任何「卖得慢」都会触发以下放大器，把 AGL 的头程红利彻底吞掉。</p>
  <div class="risk-cards">
    <div class="risk"><h3>① 超龄库存附加费</h3><p>滞留 <b>&gt;180 天</b> 起收 $0.50/cuft/月，271 天跳 10 倍档 $5.45。M5 = 4.03 cuft，180 天后每月约 <b>$2.02/台</b>；若拖到 271 天+ 每月 <b>$22/台</b>。备 2027 年货几乎必触发。</p></div>
    <div class="risk"><h3>② 仓储利用率附加费</h3><p>大件分段仓储利用率 <b>&gt;22 周</b> 触发：22–28 周 +$0.23/cuft/月，&gt;52 周 +$1.26/cuft/月。整柜集中到货、三柜同月，账户级 22.4 周即过线（AGL 评估 N 系列先例：利用率附加单柜 26 万）。</p></div>
    <div class="risk"><h3>③ 危险品费率放大 1.74×</h3><p>M5 是锂电池整机（Class 9）。旺季大件仓储 <b>危险品 $2.43</b> vs 普货 $1.40；非旺 $0.78 vs $0.56。此前 AGL 切换评估用普货价，低估了 M 系列仓储。</p></div>
    <div class="risk"><h3>④ 旺季窗口不可躲</h3><p>FBA 仓储旺季 = <b>10/11/12 整月</b>（$2.43），配送费旺季 10/15–1/14。H2 到仓几乎必然撞上；1/1–1/14 仓储已回落但配送仍旺季。</p></div>
    <div class="risk"><h3>⑤ 移除/弃置费</h3><p>卖不掉清仓也要钱（超大件移除按件收），N 系列先例移除费 $8.17 万/柜。FBA 模式无「缓一缓」，只有继续付仓储或花钱移除。</p></div>
    <div class="risk"><h3>⑥ 与既往结论的偏差</h3><p>AGL 差异看板 v1.1 的「M 整柜稳赚 ¥209/台」用了 <b>钉钉低尾程 ¥161.4（$22.26）</b> + 普货仓储 $1.40。按官方费率（尾程 $39 + 危险品 $2.43）重算即翻盘。</p></div>
  </div>
</section>

<section>
  <h2>与既往结论调和 —— 为什么「M 整柜稳赚」这次变亏</h2>
  <p class="lede">不是数据打架，是口径升级：三次结论看的是同一条 M 线，费率基础一次比一次接近官方。</p>
  <div class="tblwrap">
  <table>
    <thead><tr><th>版本</th><th>尾程口径</th><th>仓储口径</th><th>仓储天数</th><th>M 结论</th></tr></thead>
    <tbody>
    <tr><td class="sname">AGL 切换评估 (08-19)</td><td>钉钉 ¥161.4/台 = $22.26</td><td>普货大件 $1.40(旺)</td><td>545 天逐日仿真·动态</td><td class="neg">整柜稳赚 −10.2~12.8万/柜</td></tr>
    <tr><td class="sname">M 尾端履约结论 (08-25)</td><td>官方 $37.32(非旺)/超大件</td><td>—（只比尾端）</td><td>—</td><td class="pos">现状超大件 恒谷仓（安全边际 ¥1.02）</td></tr>
    <tr><td class="sname">本次 H2 对比 (08-26)</td><td>官方 $39(H2 混算)/超大件</td><td>危险品大件 $2.43(旺)</td><td>静态 90 天</td><td class="pos">AGL 整柜每台贵 ${fmt(DELTA)}（分水岭 67 天）</td></tr>
    </tbody>
  </table>
  </div>
  <p class="foot">差异看板那版用了官方校准前口径（钉钉报价低尾程 + 普货仓储），夸大了 M 的 AGL 红利。若按官方费率对 545 天仿真重算，M 的「稳赚」区间显著收窄到快销品。</p>
</section>

<section>
  <h2>决策框架 —— 不搞一刀切，按周转分流</h2>
  <div class="levers">
    <ol>
      <li><b>快销品（预期 D ≤ 60 天）→ AGL 整柜可行</b>：30 天口径 AGL 每台省 $8.5（危险品旺季）/ $12–16（其他情景）。前提：库存按销量比例配货、不停留。</li>
      <li><b>中速品（D 60–90 天）→ 持平区，逐 SKU 测算</b>：正好压在分水岭两侧，一两个星期误差即翻盘，按真实动销数据单点核算。</li>
      <li><b>慢销 / 备货 / 2027 预报（D &gt; 90 天）→ 一律留海外仓</b>：FBA 月度仓储 + 超龄 + 利用率 = 无底洞，海外仓滞留成本低、可发 FBM 控库存。</li>
      <li><b>先压包装、再切 AGL（战略杠杆）</b>：M5 体积重 50.2lb 刚过 50lb 线，包装毫米级压缩回落「小号大件」→ FBA 尾程 $39 → $23.92（−$15/台），AGL 在 90 天危险品旺季下也能转赢。</li>
      <li><b>到仓节奏避让旺季</b>：Q4 危险品仓储 $2.43 是普货 1.74 倍，能避开 10–12 月到仓就避；非旺 $0.78 时 AGL 几乎全天候赢。</li>
    </ol>
  </div>
  <p class="foot"><b>一句话结论：</b>H2 物流「全盘按 AGL 跑」不可行；「按周转分流跑 AGL」可行——头程红利 $17.65/台 只属于 60 天内卖得掉的货，危险品 × 旺季 × 慢周转是 AGL 的禁区。</p>
</section>

<p class="foot">
  <b>口径与局限：</b>① 主口径复现对比文件（M5 · 危险品锂电 · 超大件 50–70 · 500 台/柜 · 汇率 6.8 · 静态 90 天仓储），AGL 仓储按危险品·旺季 $2.43/cuft/月 全旺季口径（偏保守）；海外仓仓储按 ¥0.86/方/天 直算 $8.84（若 ÷6.8 折算则海外仓合计 $76.24，AGL 贵 $12.73，方向不变）。
  ② 分水岭基于「滞留天数×月费率」线性外推，未建模逐日销量衰减——真实动销下 FBA 仓储低于静态上限，对 AGL 略有利。
  ③ 未计资金占用、退货处理、低库存费、时效/转化率差异、以及 AGL 整柜的舱位/截单合规成本。
  ④ 尾程 $39 = (37.32×3+40.13×3)/6 的 H2 混算，对比文件取 39。⑤ 复用资产：仿真模型 <b>scripts/agl_vs_forwarder_sim.py</b>、官方费率 <b>data/fba_us_cost_model.json</b>、收费明细 <b>output/fba_fee_detail.html</b>、AGL 差异看板 <b>output/agl_diff_dashboard.html</b>。
</p>

</div>
</body>
</html>"""


# ── 5. Markdown 摘要 ─────────────────────────────────────────────────────
def build_md() -> str:
    return f"""# H2 物流 AGL 可行性方案结论（v1.0 定稿）

> 生成 {GENERATED} · 基于《美国海外仓VS美国AGL（FBA仓）物流费用对比.xlsx》公式复现 · M5 为例（68×48×35cm / 危险品锂电 / 超大件 50–70 / 500台·40HQ / 汇率 6.8）

## 一句话结论

**H2 物流「全盘按 AGL 跑」不可行；「按周转分流跑 AGL」可行。**

90 天库存、危险品旺季仓储口径下，AGL 整柜每台**贵 ${fmt(DELTA)}**（海外仓 $83.78 → AGL $88.97）。
AGL 的头程红利每台 **$17.65**（头程半价 ¥70k vs ¥130k/柜 + 免入库操作费 $0.71）真实存在，但被 FBA 尾程（+$3）与旺季危险品仓储（+$20.54）反超。

## 分水岭 = 周转天数 D ≈ 67 天

| 滞留 D | AGL−海外仓(US$/台) · 危险品旺季 | 危险品非旺 | 普货旺季 | 普货非旺 |
|---|---|---|---|---|
| 30 天 | −8.51 | −15.16 | −12.66 | −16.04 |
| 60 天 | −1.66 | −14.96 | −9.96 | −16.73 |
| **90 天** | **+5.18** | −14.76 | −7.27 | −17.42 |
| 120 天 | +12.03 | −14.57 | −4.57 | −18.12 |
| 180 天 | +25.72 | −14.18 | **+0.81** | −19.50 |

- 危险品 × 旺季是唯一能击穿 AGL 红利的组合：分水岭 **67 天**。
- 普货 × 旺季分水岭 171 天；非旺情景 AGL 几乎全天候省。
- 若谷仓仓储 ¥0.86/方/天 按 RMB÷6.8 折算（$1.30/90天），海外仓合计 $76.24，AGL 每台贵 **$12.73**，分水岭 D≈**49 天** —— 结论方向不变且更保守。

## 决策框架

1. **快销品（D ≤ 60 天）→ AGL 整柜可行**（30 天口径每台省 $8.5~16）。
2. **中速品（D 60–90 天）→ 持平区，逐 SKU 测算**。
3. **慢销 / 备货 / 2027 预报（D > 90 天）→ 一律留海外仓**（避开 FBA 月度仓储 + 超龄 + 利用率黑洞）。
4. **先压包装、再切 AGL（战略杠杆）**：M5 体积重 50.2lb 刚过 50lb 线，压回「小号大件」→ FBA 尾程 $39→$23.92，AGL 在 90 天危险品旺季也能转赢。
5. **到仓避让旺季**：Q4 危险品仓储 $2.43 是普货 1.74×，非旺 $0.78 时 AGL 全天候赢。

## 风险放大量

- **超龄附加费**：>180 天 $0.50/cuft/月 起，271 天跳 10 倍档 $5.45；M5=4.03cuft，180 天后每月 ~$2.02/台，拖到 271 天+ 每月 ~$22/台。
- **仓储利用率附加费**：大件 >22 周触发（+$0.23/cuft/月，>52 周 +$1.26）；整柜集中到货即过线（N 系列先例单柜 26 万）。
- **危险品费率放大 1.74×**：旺季 $2.43 vs 普货 $1.40 —— 此前 AGL 切换评估用普货价低估了 M 系列仓储。
- **移除/弃置费**：卖不掉清仓也花钱，FBA 无「缓一缓」选项。

## 与既往结论调和

| 版本 | 尾程口径 | 仓储口径 | M 结论 |
|---|---|---|---|
| AGL 切换评估 (08-19) | 钉钉 ¥161.4/台=$22.26 | 普货 $1.40(旺) | 整柜稳赚 −10.2~12.8万/柜 |
| M 尾端履约结论 (08-25) | 官方 $37.32 | — | 现状超大件恒谷仓 |
| **本次 H2 对比 (08-26)** | **官方 $39** | **危险品 $2.43(旺)** | **AGL 每台贵 ${fmt(DELTA)}（分水岭 67 天）** |

差异看板 v1.1 的「M 整柜稳赚」用了官方校准前口径（钉钉低尾程 + 普货仓储），夸大了 AGL 红利；按官方费率重算即收窄到快销品。

## 交付物

- **结论报告**: `output/agl_h2_feasibility_conclusion.html`（自包含双击即开 · 瀑布图 + 盈亏平衡曲线 + 敏感度矩阵 + 风险放大器 + 决策框架 + 与既往结论调和）
- **可复现模型**: `scripts/build_agl_h2_conclusion.py`
- **源对比文件**: `美国海外仓VS美国AGL（FBA仓）物流费用对比.xlsx`
- 复用: `scripts/agl_vs_forwarder_sim.py` / `data/fba_us_cost_model.json` / `output/fba_fee_detail.html` / `output/agl_diff_dashboard.html`
"""


GENERATED = "2026-08-26"
HTML_PATH = r"C:\Users\LD1621\Desktop\FBA报价分析\output\agl_h2_feasibility_conclusion.html"
MD_PATH = r"C:\Users\LD1621\Desktop\FBA报价分析\output\agl_h2_feasibility_conclusion.md"

if __name__ == "__main__":
    import sys, io
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    # 校验块
    print("== 校验 ==")
    print(f"A 海外仓: 头程{A['head']:.4f} 入库{A['inbound']:.4f} 尾程{A['tail']:.2f} 仓储90天{A['stor_90']:.4f} 合计{A['total']:.4f}")
    print(f"B AGL: 头程{B['head']:.4f} 尾程{B['tail']:.2f} 仓储90天{B['stor_90']:.4f} 合计{B['total']:.4f}")
    print(f"Δ 合计 = {DELTA:.4f} (AGL 贵)")
    print(f"除仓储外 AGL 省 = {AGL_ADV_NONSTOR:.4f} | 分水岭 = {BE_DAYS:.1f} 天 | 修正口径 Δ = {DELTA_CORR:.4f}, 分水岭 = {BE_DAYS_CORR:.1f} 天")
    for name, rate, key in SCEN:
        print(f"  {name}: 分水岭 {be_days_for(rate):.1f} 天, D90 Δ = {delta_at(90,rate):+.2f}")
    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(build_html())
    with open(MD_PATH, "w", encoding="utf-8") as f:
        f.write(build_md())
    print(f"已生成: {HTML_PATH}")
    print(f"已生成: {MD_PATH}")
